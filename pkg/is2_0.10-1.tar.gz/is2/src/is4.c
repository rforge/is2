// -*- C++ -*-


#include <Rdefines.h>
# define MATCHNAMES(X,N,W) (matchnames(GET_NAMES(X),(N),(W)))
# define MATCHROWNAMES(X,N,W) (matchnames(GET_ROWNAMES(GET_DIMNAMES(X)),(N),(W)))

static R_INLINE SEXP matchnames (SEXP x, SEXP names, const char *where) {
  int nprotect = 0;
  int n = length(names);
  int *idx, k;
  SEXP index, nm;
  PROTECT(nm = AS_CHARACTER(names)); nprotect++;
  PROTECT(index = match(x,names,0)); nprotect++;
  idx = INTEGER(index);
  for (k = 0; k < n; k++) {
    if (idx[k]==0) 
      error("variable '%s' not found among the %s",
	    CHARACTER_DATA(STRING_ELT(nm,k)),
	    where);
    idx[k] -= 1;
  }
  UNPROTECT(nprotect);
  return index;
}


// implements the Ionides et al. (2006) MIF update rule

SEXP is4_update (SEXP pfp, SEXP theta, SEXP gamma, SEXP varfactor, 
		 SEXP sigma, SEXP pars, SEXP lag)
{
  int nprotect = 0;
  double *v, *m1, *m2;
  double scal, sig, grad, hess, l;
  int npar, ntimes, nfm, npv;
  SEXP FM, PV, newtheta;
  int *sidx, *thidx, *midx, *vidx, *dim;
  int i, j;

  //sig = *(REAL(varfactor));
  scal = *(REAL(gamma));

  PROTECT(FM = GET_SLOT(pfp,install("filter.mean"))); nprotect++;
  PROTECT(PV = GET_SLOT(pfp,install("pred.var"))); nprotect++;

  npar = LENGTH(pars);
  dim = INTEGER(GET_DIM(FM)); nfm = dim[0]; ntimes = dim[1];
  dim = INTEGER(GET_DIM(PV)); npv = dim[0];

  sidx = INTEGER(PROTECT(MATCHNAMES(sigma,pars,"random-walk SDs"))); nprotect++;
  thidx = INTEGER(PROTECT(MATCHNAMES(theta,pars,"parameters"))); nprotect++;
  midx = INTEGER(PROTECT(MATCHROWNAMES(FM,pars,"filter-mean variables"))); nprotect++;
  vidx = INTEGER(PROTECT(MATCHROWNAMES(PV,pars,"prediction-variance variables"))); nprotect++;

  PROTECT(newtheta = duplicate(theta)); nprotect++;
  l = *(REAL(lag));
  for (i = 0; i < npar; i++) {
    sig = REAL(sigma)[sidx[i]];
    m1 = REAL(theta)+thidx[i];
    m2 = REAL(FM)+midx[i];
    v = REAL(PV)+vidx[i];
		grad=0;
		hess=0;    
		if(l==0){		
				grad=(*m2-*m1);
				hess=(*v)/ntimes-sig*sig;
				for (j = 1, m2 += nfm, v += npv; j < ntimes; j++, m2 += nfm, v += npv)
				{ 
      			grad += (*m2-*m1);
						hess += (*v)/ntimes-sig*sig;
				}
		}
		else{
		for (j = l, m2 += nfm, v += npv; j < ntimes-1; j++, m2 += nfm, v += npv)
		{ 
      	grad += (*m2-*m1);
				hess += (*v)/ntimes-sig*sig;
		}
		grad += (l+1)*(*m2-*m1);
		hess += (l+1)*((*v)/ntimes-sig*sig);
		}
    REAL(newtheta)[thidx[i]] -= scal*sig*sig*grad/hess;
  }

  UNPROTECT(nprotect);
  return newtheta;
}
