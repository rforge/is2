## SMC (particle filter) and use for fixed lag smoothing
setGeneric("pfilter2",function(object,...)standardGeneric("pfilter2"))

## iterated smoothing
setGeneric('is2',function(object,...)standardGeneric("is2"))


